column names:

'name' = neighbourhood name
'nc_id' = neighourhood council id (drop if not needed)
'geometry' = neighbourhood polygon
'trepass_count' = number of trespassing incidence in the neighbourhood from year 2010 to 2019